## Lab 8 data sources

| layer               | source                                                                     |
| ------------------- | -------------------------------------------------------------------------- |
| `cali_wind.tif`     | [Global Wind Atlas](https://globalwindatlas.info/)                         |
| `california.gpkg`   |                                                                            |
| `precipitation.tif` | [EarthWorks](https://earthworks.stanford.edu/catalog/stanford-td754wr4701) |
| `TEMP.tif`          | [Global Solar Atlas](https://globalsolaratlas.info/download/usa)           |
| `watersheds.gpkg`   |                                                                            |

